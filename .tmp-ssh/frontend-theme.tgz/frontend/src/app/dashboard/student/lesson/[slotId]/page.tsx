'use client';

import { Suspense, useEffect, useState } from 'react';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';
import { api } from '@/lib/api';
import { LessonRoom } from '@/components/lesson/lesson-room';
import { parseLessonViewMode } from '@/lib/lesson';
import type { LessonStatus } from '@/types';

function Loading() {
  return (
    <div className="flex h-[calc(100vh-56px)] items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
    </div>
  );
}

function StudentLessonRoom({
  token,
  livekitUrl,
  lessonId,
  lessonStatus,
}: {
  token: string;
  livekitUrl: string;
  lessonId: string;
  lessonStatus: LessonStatus;
}) {
  const searchParams = useSearchParams();
  return (
    <LessonRoom
      token={token}
      livekitUrl={livekitUrl}
      lessonId={lessonId}
      initialStatus={lessonStatus}
      isTeacher={false}
      backHref="/dashboard/student/bookings"
      title="Урок"
      initialViewMode={parseLessonViewMode(searchParams.get('view'))}
    />
  );
}

export default function StudentLessonPage() {
  const { slotId } = useParams<{ slotId: string }>();
  const router = useRouter();
  const [connection, setConnection] = useState<{
    token: string;
    lessonId: string;
    lessonStatus: LessonStatus;
    livekitUrl: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get<{
        token: string;
        url?: string;
        room: string;
        lessonId: string;
        lessonStatus: LessonStatus;
      }>(`/video/token?slotId=${slotId}`)
      .then((data) =>
        setConnection({
          ...data,
          livekitUrl:
            data.url ||
            process.env.NEXT_PUBLIC_LIVEKIT_URL ||
            'ws://localhost:7890',
        }),
      )
      .catch((err) => {
        toast.error(err.response?.data?.message || 'Не удалось получить доступ к уроку');
        router.push('/dashboard/student/bookings');
      })
      .finally(() => setLoading(false));
  }, [slotId, router]);

  if (loading) return <Loading />;
  if (!connection) return null;

  return (
    <Suspense fallback={<Loading />}>
      <StudentLessonRoom
        token={connection.token}
        livekitUrl={connection.livekitUrl}
        lessonId={connection.lessonId}
        lessonStatus={connection.lessonStatus}
      />
    </Suspense>
  );
}
